
from jupiter_lib.jupiter import Jupiter

def main():
    jup = Jupiter("dummy_connection")
    print(jup.simulate_trade())

if __name__ == "__main__":
    main()
