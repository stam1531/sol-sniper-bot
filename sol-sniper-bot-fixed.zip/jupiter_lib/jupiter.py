
class Jupiter:
    def __init__(self, connection):
        self.connection = connection

    def simulate_trade(self):
        return "Simulated trade"
