class Jupiter:
    def __init__(self):
        pass
